package com.training.main;

import org.hibernate.Session;
import com.training.pojo.Student;
import com.training.util.DbUtil;

public class MainClass {

	public static void main(String[] args) {

		Session sessionObj = null;
		try {
			sessionObj = DbUtil.getConnection().openSession();
			sessionObj.beginTransaction();
			Student obj = new Student();
			obj.setIdno(102);
			obj.setEmail("bob@gmail.com");
			obj.setFirst_name("Hadour");
			obj.setLast_name("k");
			sessionObj.save(obj);
			sessionObj.getTransaction().commit();

		} catch (Exception e) {

			e.printStackTrace();

		} finally {
			sessionObj.close();
		}
	}

}
