package com.training.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class DbUtil {

	public static SessionFactory getConnection()
	{
		Configuration configObj=null;
		SessionFactory sessionFactoryObj =null;
		configObj = new Configuration();
		configObj.configure("hibernate.cfg.xml");
		ServiceRegistry  serviceRegistryObj = new StandardServiceRegistryBuilder().applySettings(configObj.getProperties()).build(); 
		sessionFactoryObj = configObj.buildSessionFactory(serviceRegistryObj);
		return sessionFactoryObj;
	}
	
}
