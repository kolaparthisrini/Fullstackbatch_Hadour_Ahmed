package org.cap.pojo;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Employee {
	
	private int empId;
	
	@NotEmpty(message="*Please enter FirstName.")
	private String firstName;
	
	@NotEmpty(message="* Please enter LastName.")
	@Length(min=5,max=15,message="* Last name should be between 5 to 15 chars. ")
	private String lastName;
	
	@Range(min=20000,max=200000,message="*Salary between 20000 to 2laks.")
	private double salary;
	
	@Email(message="*Please enter valid Email.")
	private String email;
	
	@NotNull(message="*Please enter Date.")
	@Past(message="*Date of Birth must be past date.")
	private Date empDob;
	
	@Future(message="*Date of Joining must be future date.")
	private Date empDoj;
	
	public Employee() {
		
	}
	
	
	public Employee(int empId, String firstName, String lastName, double salary, String email, Date empDob,
			Date empDoj) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.email = email;
		this.empDob = empDob;
		this.empDoj = empDoj;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", email=" + email + ", empDob=" + empDob + ", empDoj=" + empDoj + "]";
	}
	
	

}
