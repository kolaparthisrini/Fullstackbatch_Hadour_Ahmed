package org.cap.controller;

import javax.validation.Valid;

import org.cap.pojo.Employee;
import org.cap.service.EmployeeServiceImpl;
import org.cap.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		//viewObject,modelAttributeName,modelAttributeValue
		return new ModelAndView("helloPage",
				"message","Hello! Welcome to Spring3!");
	}
	
	@RequestMapping("/employeeForm")
	public ModelAndView getEmployeeForm() {
		return new ModelAndView("employee","emp",new Employee());
	}
	
	
	
	@RequestMapping(value="/saveEmployee",
			method=RequestMethod.POST)
	public String showEmployee(
			@Valid @ModelAttribute("emp")Employee employee,
			BindingResult result) {
		if(result.hasErrors()) {
			System.out.println(result);
			return "employee";
		}else {
			System.out.println(employee);	
			employeeService.insertEmployee(employee);
		
		return "showEmp";
		}
	}
	
	
	
	
	

}
